
merged_fruit_set - v1 base
==============================

This dataset was exported via roboflow.ai on July 14, 2021 at 4:23 AM GMT

It includes 30 images.
Berries are annotated in COCO format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


